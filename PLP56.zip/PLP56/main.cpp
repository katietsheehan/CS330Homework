#include <iostream>
#include <vector>
using namespace std;

int g_x = 3;

//#1
void MyFunction(){
    cout << "This is a function" << endl;
}

//recursive function #3
int Factorial(int x){
    if (x > 1){
        return x * Factorial(x-1);
    }
    else{
        return 1;
    }
}
void Person(int age, string name){
    cout << name << " is " << age << " years old" <<endl;
}


int main() {
    std::cout << "Hello, World!" << std::endl;
    //#1
    MyFunction();

//#3
    int num = Factorial(5);
    cout<< num<< endl;

//#4
    Person(20, "Katie");

    //#6
    int x = 5;

    for (int i = 0; i<3; i++){
        int x;
        x += i;
        cout <<"in the loop: "<<  x << endl;
    }
    cout << x << endl;

    // #8
    cout << x+g_x << endl;

    //#10
    char a []= {'c','a','t'};
    char b []= {'d','o','g'};
    //a = b; //get an error
    b[1] = 'u';
    cout<< a << endl;
    cout<< b << endl;






    return 0;

}

