#include <iostream>
#include <vector>
#include <sstream>
using namespace std;
int main() {
    int integer_one = 5;
    cout << "integer: " + to_string(integer_one) << endl;

    float float_one = 2.5;
    cout << "float: " + to_string(float_one) << " OR ";
    printf("%.1f", float_one);
    cout<<endl;

    float added_float = integer_one + float_one;
    cout << "added float and integer: " + to_string(added_float) << " OR ";
    printf("%.1f", added_float);
    cout<<endl;

    string s = "Hello";
    cout <<"string: " + s <<endl;

    bool b = true;
    cout << "boolean: "<< b << endl;

    vector<int> v = {1,2,3,4,5};
    cout << "vector v at index 3: " << v.at(3) << endl;

    int array[5];
    array[0]=1;
    array[1]=2;
    array[2]=3;
    array[3]=4;
    array[4]=5;
    for( int i = 0; i< 5; i++ )
        cout<<array[i] << " ";
    cout<< endl;

    // example of string-int type conversion.

    string num = "5";
    stringstream stringstream1(num);
    int real_num;
    stringstream1 >> real_num;
    int total = real_num + integer_one;
    cout << "5 + 5 = " << to_string(total) <<endl;










    return 0;
}