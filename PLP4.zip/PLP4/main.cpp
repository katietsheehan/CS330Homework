#include <iostream>
#include <vector>
using namespace std;
int main() {
//  if/else and single condition while loop
    int num = 5;
    while(num > 0) {
        if (num%2 == 0) {
            cout << "even" << endl;
        } else {
            cout << "odd" << endl;
        }
        num -= 1;
    }
    cout<<endl;
    //if/else if/else and multi condition do while
    num = -5;
    do{
        if(num < 0){
            cout << "negative integer" << endl;
        }
        else if(num > 0){
            cout << "positive integer" << endl;
        }
        else{
            cout << "zero"<< endl;
        }
        num += 1;

    }
    while(num >= -5 && num <= 5);

    //Switch and counting for loop
    for(num = 0; num < 4; num ++) {
        switch (num) {
            case 1:
                cout << "number is 1" << endl;
                break;
            case 2:
                cout << "number is 2" << endl;
                break;
            case 3:
                cout << "number is 3" << endl;
                break;
            case 4:
                cout << "number is 4" << endl;
                break;
            case 5:
                cout << "number is 5" << endl;
                break;
            default:
                cout << "number out of range" << endl;
        }
    }


    //for each and break statements
    vector <string> v = {"dog","cat","rat","lizard","horse","bird"};
    for (string animal : v){
        if(animal == "lizard"){
            cout<<"Lizard found!"<<endl;
            break;
        }
        else{
            cout<<"not a lizard."<<endl;
        }
    }
    //continue statement
    for (string animal : v){
        if(animal == "lizard"){
            continue;
        }
        cout << "my pet "<< animal << endl;
    }

    return 0;
}